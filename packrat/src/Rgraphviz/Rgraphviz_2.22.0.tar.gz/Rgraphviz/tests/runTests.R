require("Rgraphviz") || stop("unable to load Rgraphviz")
BiocGenerics:::testPackage("Rgraphviz")
