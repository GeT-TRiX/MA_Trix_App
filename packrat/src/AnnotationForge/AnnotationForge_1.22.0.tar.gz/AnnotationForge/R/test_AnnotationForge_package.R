.test <- function() BiocGenerics:::testPackage("AnnotationForge")
